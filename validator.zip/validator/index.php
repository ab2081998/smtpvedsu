<?php
ini_set('memory_limit', '512M');
session_start();

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'aman_email';

try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$dbname` ");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `aman_email` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `filename` VARCHAR(255) NOT NULL,
        `batch_id` VARCHAR(50) DEFAULT NULL,
        `email` VARCHAR(255) NOT NULL,
        `status` VARCHAR(50) NOT NULL DEFAULT 'Pending',
        `reason` VARCHAR(255) DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `idx_unique_email` (`email`),
        KEY `idx_status` (`status`),
        KEY `idx_filename` (`filename`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $db = $pdo;
} catch (PDOException $e) {
    die("XAMPP MySQL Connection Failed: " . $e->getMessage());
}

$senderEmail = $_SESSION['sender_email'] ?? 'info@yourdomain.com';

if (isset($_POST['save_sender_email'])) {
    $_SESSION['sender_email'] = trim($_POST['sender_email']);
    header("Location: index.php");
    exit;
}

function verifyEmailDeep($email, $senderEmail) {
    $email = trim($email);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['status' => 'Invalid ❌', 'reason' => 'Invalid Syntax'];
    }

    $domain = substr(strrchr($email, "@"), 1);

    if (!checkdnsrr($domain, "MX")) {
        return ['status' => 'Invalid ❌', 'reason' => 'Domain/MX Not Found'];
    }

    getmxrr($domain, $mxhosts);
    if (empty($mxhosts)) {
        return ['status' => 'Invalid ❌', 'reason' => 'No Mail Host Available'];
    }

    $connectHost = $mxhosts[0];
    $senderDomain = substr(strrchr($senderEmail, "@"), 1) ?: "localhost";

    $timeout = 3;
    $errno = 0; $errstr = '';
    $connection = @stream_socket_client("tcp://{$connectHost}:25", $errno, $errstr, $timeout);

    if (!$connection) {
        return ['status' => 'Port 25 Blocked ⚠️', 'reason' => 'ISP/Firewall Blocking Port 25'];
    }

    stream_set_timeout($connection, $timeout);

    $readResponse = function() use ($connection) {
        $res = "";
        while ($str = @fgets($connection, 512)) {
            $res .= $str;
            if (substr($str, 3, 1) == " ") break;
        }
        return $res;
    };

    $sendCommand = function($cmd) use ($connection) {
        @fputs($connection, $cmd . "\r\n");
    };

    $resConnect = $readResponse();
    $sendCommand("HELO " . $senderDomain);
    $resHelo = $readResponse();

    $sendCommand("MAIL FROM: <" . $senderEmail . ">");
    $resMailFrom = $readResponse();

    if (substr($resMailFrom, 0, 3) !== '250') {
        $sendCommand("QUIT");
        @fclose($connection);
        return ['status' => 'MX Valid ⚠️', 'reason' => 'Sender Rejected'];
    }

    $sendCommand("RCPT TO: <" . $email . ">");
    $resRcpt = $readResponse();

    $sendCommand("QUIT");
    @fclose($connection);

    $code = substr($resRcpt, 0, 3);

    if ($code === '250' || $code === '251') {
        return ['status' => 'Valid ✅', 'reason' => 'Mailbox Exists (250 OK)'];
    } elseif (in_array($code, ['550', '551', '552', '553', '501'])) {
        return ['status' => 'Invalid ❌', 'reason' => 'Mailbox Not Found (' . $code . ')'];
    } elseif (in_array($code, ['450', '451', '452'])) {
        return ['status' => 'MX Valid ⚠️', 'reason' => 'Rate-Limited / Greylisted (' . $code . ')'];
    } else {
        return ['status' => 'MX Valid ⚠️', 'reason' => 'Catch-All Server / Protected (' . $code . ')'];
    }
}

// BATCH PROCESSOR AJAX
if (isset($_GET['action']) && $_GET['action'] === 'process_batch') {
    header('Content-Type: application/json');

    $stmt = $db->query("SELECT id, email, filename FROM aman_email WHERE status = 'Pending' ORDER BY id ASC LIMIT 5");
    $pendingRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($pendingRows)) {
        echo json_encode(['status' => 'finished']);
        exit;
    }

    $updateStmt = $db->prepare("UPDATE aman_email SET status = :status, reason = :reason WHERE id = :id");

    $lastEmail = ''; $lastId = 0; $lastFile = '';

    foreach ($pendingRows as $row) {
        $res = verifyEmailDeep($row['email'], $senderEmail);
        $updateStmt->execute([
            ':status' => $res['status'],
            ':reason' => $res['reason'],
            ':id'     => $row['id']
        ]);
        $lastEmail = $row['email'];
        $lastId = $row['id'];
        $lastFile = $row['filename'];
        usleep(50000);
    }

    $remaining = $db->query("SELECT COUNT(*) FROM aman_email WHERE status = 'Pending'")->fetchColumn();
    $total = $db->query("SELECT COUNT(*) FROM aman_email")->fetchColumn();
    $processed = $total - $remaining;

    echo json_encode([
        'status' => 'processing',
        'processed' => $processed,
        'remaining' => $remaining,
        'total' => $total,
        'last_email' => $lastEmail,
        'last_id' => $lastId,
        'last_file' => $lastFile,
        'percentage' => round(($processed / $total) * 100)
    ]);
    exit;
}

// CSV UPLOAD HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $uploadedFileName = $_FILES['csv_file']['name'];
    $tmpFile = $_FILES['csv_file']['tmp_name'];

    if (($handle = fopen($tmpFile, "r")) !== FALSE) {
        $batchId = uniqid('batch_');
        $row = 0;

        $stmtInsert = $db->prepare("INSERT IGNORE INTO aman_email (filename, batch_id, email, status) VALUES (:filename, :batch_id, :email, 'Pending')");

        $db->beginTransaction();
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $email = isset($data[0]) ? trim($data[0]) : '';

            if ($row === 0 && (strtolower($email) === 'email' || strtolower($email) === 'emails')) {
                $row++; continue;
            }

            if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $stmtInsert->execute([
                    ':filename' => $uploadedFileName,
                    ':batch_id' => $batchId,
                    ':email'    => $email
                ]);
            }
            $row++;
        }
        $db->commit();
        fclose($handle);

        header("Location: index.php?start=1");
        exit;
    }
}

// Clear Database Action
if (isset($_POST['clear_database'])) {
    $db->exec("TRUNCATE TABLE aman_email");
    header("Location: index.php");
    exit;
}

$totalCount   = $db->query("SELECT COUNT(*) FROM aman_email")->fetchColumn();
$pendingCount = $db->query("SELECT COUNT(*) FROM aman_email WHERE status = 'Pending'")->fetchColumn();
$validCount   = $db->query("SELECT COUNT(*) FROM aman_email WHERE status LIKE '%Valid%' AND status NOT LIKE '%Port 25%'")->fetchColumn();
$invalidCount = $db->query("SELECT COUNT(*) FROM aman_email WHERE status LIKE '%Invalid%' OR status LIKE '%Port 25%'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload & Verifier - `aman_email`</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; margin: 30px; background-color: #f8f9fa; color: #333; }
        .card { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); max-width: 900px; margin: 0 auto 20px auto; }
        .btn { background-color: #2563eb; color: #fff; border: none; padding: 10px 18px; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; }
        .btn:hover { background-color: #1d4ed8; }
        .btn-success { background-color: #16a34a; }
        .btn-danger { background-color: #dc2626; }
        .btn-results { background-color: #0d9488; color: white; text-decoration: none; padding: 10px 18px; border-radius: 5px; font-weight: bold; }
        .progress-box { background: #e2e8f0; border-radius: 10px; height: 22px; width: 100%; overflow: hidden; margin: 15px 0; display: none; }
        .progress-bar { background: #2563eb; height: 100%; width: 0%; transition: width 0.3s; text-align: center; color: white; font-size: 12px; line-height: 22px; font-weight: bold; }
    </style>
</head>
<body>

    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0;">🚀 Email Verifier (Upload Unit)</h2>
            <a href="results.php" class="btn btn-results">📊 View All Results & Filters ➡️</a>
        </div>

        <!-- Sender Email -->
        <form method="POST" style="margin-bottom: 20px;">
            <label><strong>📧 Sender Handshake Email:</strong></label>
            <input type="email" name="sender_email" value="<?php echo htmlspecialchars($senderEmail); ?>" required style="padding: 6px; width: 250px;">
            <button type="submit" name="save_sender_email" class="btn" style="padding: 6px 12px;">Save</button>
        </form>

        <!-- CSV Form -->
        <form method="POST" enctype="multipart/form-data">
            <label><strong>Upload CSV File:</strong></label><br>
            <input type="file" name="csv_file" accept=".csv" required style="margin: 10px 0;"><br>
            <button type="submit" class="btn">🚀 Upload & Queue into `aman_email`</button>
        </form>

        <!-- Progress Bar -->
        <div id="progressContainer" class="progress-box">
            <div id="progressBar" class="progress-bar">0%</div>
        </div>
        <p id="statusText" style="font-weight: bold; color: #1e293b; margin-top: 10px;"></p>

        <?php if ($totalCount > 0): ?>
            <hr style="margin: 20px 0;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <div>
                    <strong>Total:</strong> <?php echo $totalCount; ?> | 
                    <strong style="color:#16a34a;">Valid:</strong> <?php echo $validCount; ?> | 
                    <strong style="color:#dc2626;">Invalid:</strong> <?php echo $invalidCount; ?> | 
                    <strong style="color:#64748b;">Pending:</strong> <span id="pendingCnt"><?php echo $pendingCount; ?></span>
                </div>
                <div>
                    <?php if ($pendingCount > 0): ?>
                        <button onclick="startProcessing()" class="btn" id="startBtn">▶️ Start / Resume Processing</button>
                    <?php endif; ?>
                    
                    <form method="POST" style="display:inline;" onsubmit="return confirm('Pura Database `aman_email` clear karein?');">
                        <button type="submit" name="clear_database" class="btn btn-danger">🗑️ Clear DB</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        let isProcessing = false;

        async function processNextBatch() {
            if (!isProcessing) return;

            try {
                let response = await fetch('index.php?action=process_batch');
                let data = await response.json();

                if (data.status === 'processing') {
                    document.getElementById('progressContainer').style.display = 'block';
                    document.getElementById('progressBar').style.width = data.percentage + '%';
                    document.getElementById('progressBar').innerText = data.percentage + '%';
                    document.getElementById('statusText').innerText = `Verifying... [File: ${data.last_file}] Last ID: #${data.last_id} (${data.last_email})`;
                    document.getElementById('pendingCnt').innerText = data.remaining;

                    processNextBatch();
                } else if (data.status === 'finished') {
                    document.getElementById('statusText').innerText = "✅ Verification Completed!";
                    setTimeout(() => window.location.href = 'results.php', 1000);
                }
            } catch (err) {
                setTimeout(processNextBatch, 3000);
            }
        }

        function startProcessing() {
            if (isProcessing) return;
            isProcessing = true;
            let btn = document.getElementById('startBtn');
            if (btn) {
                btn.disabled = true;
                btn.innerText = "Processing...";
            }
            processNextBatch();
        }

        if (new URLSearchParams(window.location.search).get('start') === '1') {
            startProcessing();
        }
    </script>
</body>
</html>