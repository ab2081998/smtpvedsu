<?php
// MEMORY EXTENSION & SESSION SETUP
ini_set('memory_limit', '512M');
session_start();

// DATABASE CONNECTION
$host = 'localhost';
$user = 'root';
$pass = ''; // Default XAMPP password
$dbname = 'aman_email';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db = $pdo;
} catch (PDOException $e) {
    die("Database Connection Failed: `aman_email` database nahi mila. Pehle `index.php` run karein.");
}

// 1. FETCH UNIQUE FILENAMES FOR DROPDOWN
$filesList = $db->query("SELECT filename, COUNT(*) as count FROM aman_email GROUP BY filename")->fetchAll(PDO::FETCH_ASSOC);

// 2. FILTER & SEARCH LOGIC
$filterStatus = $_GET['filter_status'] ?? 'all';
$filterFile   = $_GET['filter_file'] ?? 'all';
$searchQuery  = trim($_GET['search_email'] ?? '');

$whereClauses = [];
$params = [];

if ($filterStatus === 'valid') {
    $whereClauses[] = "(status LIKE '%Valid%' AND status NOT LIKE '%Port 25%')";
} elseif ($filterStatus === 'invalid') {
    $whereClauses[] = "(status LIKE '%Invalid%' OR status LIKE '%Port 25%')";
} elseif ($filterStatus === 'pending') {
    $whereClauses[] = "status = 'Pending'";
}

if ($filterFile !== 'all' && !empty($filterFile)) {
    $whereClauses[] = "filename = :filename";
    $params[':filename'] = $filterFile;
}

if (!empty($searchQuery)) {
    $whereClauses[] = "email LIKE :search";
    $params[':search'] = '%' . $searchQuery . '%';
}

// 3. EXPORT FILTERED / VALID CSV
if (isset($_POST['export_csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=filtered_emails_' . time() . '.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Source File Name', 'Email Address', 'Status', 'Reason', 'Created At']);

    $sqlExport = "SELECT id, filename, email, status, reason, created_at FROM aman_email";
    if (!empty($whereClauses)) {
        $sqlExport .= " WHERE " . implode(" AND ", $whereClauses);
    }
    $sqlExport .= " ORDER BY id DESC";

    $stmtExport = $db->prepare($sqlExport);
    $stmtExport->execute($params);

    while ($row = $stmtExport->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [$row['id'], $row['filename'], $row['email'], $row['status'], $row['reason'], $row['created_at']]);
    }
    fclose($output);
    exit;
}

// 4. FETCH DATA FOR VIEW
$sql = "SELECT * FROM aman_email";
if (!empty($whereClauses)) {
    $sql .= " WHERE " . implode(" AND ", $whereClauses);
}
$sql .= " ORDER BY id DESC LIMIT 500"; // Top 500 records

$stmtFilter = $db->prepare($sql);
$stmtFilter->execute($params);
$results = $stmtFilter->fetchAll(PDO::FETCH_ASSOC);

// STATS COUNTS
$totalCount   = $db->query("SELECT COUNT(*) FROM aman_email")->fetchColumn();
$validCount   = $db->query("SELECT COUNT(*) FROM aman_email WHERE status LIKE '%Valid%' AND status NOT LIKE '%Port 25%'")->fetchColumn();
$invalidCount = $db->query("SELECT COUNT(*) FROM aman_email WHERE status LIKE '%Invalid%' OR status LIKE '%Port 25%'")->fetchColumn();
$pendingCount = $db->query("SELECT COUNT(*) FROM aman_email WHERE status = 'Pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Results & Reports - `aman_email`</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; margin: 30px; background-color: #f8f9fa; color: #333; }
        .card { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); max-width: 1100px; margin: 0 auto 20px auto; }
        .btn { background-color: #2563eb; color: #fff; border: none; padding: 8px 16px; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; }
        .btn:hover { background-color: #1d4ed8; }
        .btn-success { background-color: #16a34a; }
        .btn-reset { background-color: #64748b; color: white; }
        .btn-back { background-color: #475569; color: white; }
        table { border-collapse: collapse; width: 100%; margin-top: 15px; }
        th, td { border: 1px solid #e2e8f0; padding: 10px; text-align: left; font-size: 13px; }
        th { background-color: #f1f5f9; }
        .valid { color: #16a34a; font-weight: bold; }
        .invalid { color: #dc2626; font-weight: bold; }
        .pending { color: #64748b; font-style: italic; }
        .filter-bar { background: #f1f5f9; padding: 15px; border-radius: 6px; margin-bottom: 15px; display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
        .filter-bar select, .filter-bar input { padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 13px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-box { background: #f8fafc; padding: 15px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center; }
        .stat-box h3 { margin: 0; font-size: 22px; color: #1e293b; }
        .stat-box p { margin: 5px 0 0 0; font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: bold; }
    </style>
</head>
<body>

    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h2>📊 Stored Email Records (`aman_email`)</h2>
            <a href="index.php" class="btn btn-back">⬅️ Back to Processing Unit</a>
        </div>

        <!-- STATS OVERVIEW -->
        <div class="stats-grid">
            <div class="stat-box">
                <h3><?php echo $totalCount; ?></h3>
                <p>Total Emails</p>
            </div>
            <div class="stat-box" style="border-top: 3px solid #16a34a;">
                <h3 style="color: #16a34a;"><?php echo $validCount; ?></h3>
                <p>Valid Emails</p>
            </div>
            <div class="stat-box" style="border-top: 3px solid #dc2626;">
                <h3 style="color: #dc2626;"><?php echo $invalidCount; ?></h3>
                <p>Invalid / Blocked</p>
            </div>
            <div class="stat-box" style="border-top: 3px solid #64748b;">
                <h3 style="color: #64748b;"><?php echo $pendingCount; ?></h3>
                <p>Pending Queue</p>
            </div>
        </div>

        <!-- SEARCH & FILTER FORM -->
        <form method="GET" class="filter-bar">
            <div>
                <label><strong>Status Filter:</strong></label><br>
                <select name="filter_status">
                    <option value="all" <?php echo $filterStatus === 'all' ? 'selected' : ''; ?>>All Statuses</option>
                    <option value="valid" <?php echo $filterStatus === 'valid' ? 'selected' : ''; ?>>Valid Only ✅</option>
                    <option value="invalid" <?php echo $filterStatus === 'invalid' ? 'selected' : ''; ?>>Invalid Only ❌</option>
                    <option value="pending" <?php echo $filterStatus === 'pending' ? 'selected' : ''; ?>>Pending Only ⏳</option>
                </select>
            </div>

            <div>
                <label><strong>File Name Filter:</strong></label><br>
                <select name="filter_file">
                    <option value="all">All Files</option>
                    <?php foreach ($filesList as $f): ?>
                        <option value="<?php echo htmlspecialchars($f['filename']); ?>" <?php echo $filterFile === $f['filename'] ? 'selected' : ''; ?>>
                            📂 <?php echo htmlspecialchars($f['filename']); ?> (<?php echo $f['count']; ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label><strong>Search Email / Domain:</strong></label><br>
                <input type="text" name="search_email" placeholder="e.g. gmail.com or name" value="<?php echo htmlspecialchars($searchQuery); ?>">
            </div>

            <div style="margin-top: 18px;">
                <button type="submit" class="btn">🔍 Filter</button>
                <a href="results.php" class="btn btn-reset">🔄 Reset</a>
            </div>
        </form>

        <!-- EXPORT FILTERED DATA -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px;">
            <span style="font-size: 13px; color: #64748b;">
                Showing <strong><?php echo count($results); ?></strong> matching records.
            </span>
            
            <form method="POST">
                <input type="hidden" name="filter_status" value="<?php echo htmlspecialchars($filterStatus); ?>">
                <input type="hidden" name="filter_file" value="<?php echo htmlspecialchars($filterFile); ?>">
                <input type="hidden" name="search_email" value="<?php echo htmlspecialchars($searchQuery); ?>">
                <button type="submit" name="export_csv" class="btn btn-success">📥 Export Current View to CSV</button>
            </form>
        </div>

        <!-- RESULTS TABLE -->
        <?php if (!empty($results)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Source File Name</th>
                    <th>Email Address</th>
                    <th>Status</th>
                    <th>Reason / Response</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td>#<?php echo $row['id']; ?></td>
                        <td><small>📂 <?php echo htmlspecialchars($row['filename']); ?></small></td>
                        <td><strong><?php echo htmlspecialchars($row['email']); ?></strong></td>
                        <td class="<?php echo (strpos($row['status'], 'Valid') !== false) ? 'valid' : ((strpos($row['status'], 'Pending') !== false) ? 'pending' : 'invalid'); ?>">
                            <?php echo $row['status']; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['reason'] ?? '-'); ?></td>
                        <td><small><?php echo $row['created_at']; ?></small></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p style="text-align:center; color:#64748b; margin:30px 0;">Koi matching record nahi mila.</p>
        <?php endif; ?>
    </div>

</body>
</html>