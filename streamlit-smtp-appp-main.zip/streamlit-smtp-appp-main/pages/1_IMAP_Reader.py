from auth import require_login
require_login()  # Agar login nahi hoga toh aage ka page load hi nahi hoga!

from datetime import datetime, time, timedelta, timezone
import email
from email.header import decode_header
import imaplib
import streamlit as st

st.set_page_config(page_title="IMAP Reader", page_icon="📧", layout="wide")

st.title("📧 IMAP Email Reader")

# --- SIDEBAR SETTINGS ---
st.sidebar.header("⚙️ IMAP Login Settings")

# Check if secrets exist or ask user input
default_server = st.secrets.get("IMAP_SERVER", "imap.gmail.com")
default_port = int(st.secrets.get("IMAP_PORT", 993))
default_user = st.secrets.get("IMAP_EMAIL", "")

imap_server = st.sidebar.text_input("IMAP Server", value=default_server)
imap_port = st.sidebar.number_input("Port", value=default_port)
email_user = st.sidebar.text_input("Email Address", value=default_user)
email_pass = st.sidebar.text_input("Password / App Password", type="password")

st.sidebar.divider()
st.sidebar.header("🔍 Filter Options")

# Filter Type Selection: Hours vs Calendar Dates
filter_type = st.sidebar.radio(
    "Date Filter Type Choose Karein:",
    options=["Last X Hours", "Custom Calendar Date Range"],
)

if filter_type == "Last X Hours":
    hours_option = st.sidebar.selectbox(
        "Kitne purane emails dekhne hain?",
        options=[1, 6, 12, 24, 48, 72, 168],
        index=3,  # Default 24 Hours
        format_func=lambda x: (
            f"Last {x} Hours" if x < 168 else "Last 7 Days (1 Week)"
        ),
    )
else:
    # Calendar Date Inputs
    today = datetime.now().date()
    start_date = st.sidebar.date_input("Start Date (Kahan se):", today - timedelta(days=1))
    end_date = st.sidebar.date_input("End Date (Kahan tak):", today)

max_emails = st.sidebar.slider("Maximum kitne emails display karein?", 1, 50, 10)


def parse_header(header_value):
    if not header_value:
        return ""
    decoded_list = decode_header(header_value)
    header_str = ""
    for decoded, encoding in decoded_list:
        if isinstance(decoded, bytes):
            header_str += decoded.decode(encoding or "utf-8", errors="ignore")
        else:
            header_str += str(decoded)
    return header_str


if st.sidebar.button("Fetch Emails", type="primary"):
    if not email_user or not email_pass:
        st.error("❌ Kripya Email Address aur Password/App Password enter karein.")
    else:
        try:
            with st.spinner("Connecting to IMAP Server..."):
                mail = imaplib.IMAP4_SSL(imap_server, port=imap_port)
                mail.login(email_user, email_pass)
                mail.select("inbox")

                # Build IMAP Search Criteria
                if filter_type == "Last X Hours":
                    time_threshold = datetime.now(timezone.utc) - timedelta(
                        hours=hours_option
                    )
                    since_date = time_threshold.strftime("%d-%b-%Y")
                    search_criterion = f'SINCE "{since_date}"'
                else:
                    # IMAP SINCE is inclusive, BEFORE requires next day to include whole end_date
                    since_str = start_date.strftime("%d-%b-%Y")
                    before_str = (end_date + timedelta(days=1)).strftime("%d-%b-%Y")
                    search_criterion = f'SINCE "{since_str}" BEFORE "{before_str}"'

                status, messages = mail.search(None, search_criterion)
                email_ids = messages[0].split()

                if not email_ids:
                    st.info("ℹ️ Is date range / time filter me koi mail nahi mila.")
                else:
                    st.success(f"✅ Total {len(email_ids)} emails mile.")

                    # Reverse list to get newest first
                    latest_ids = email_ids[::-1]
                    fetched_count = 0

                    for e_id in latest_ids:
                        if fetched_count >= max_emails:
                            break

                        res, msg_data = mail.fetch(e_id, "(RFC822)")
                        for response_part in msg_data:
                            if isinstance(response_part, tuple):
                                msg = email.message_from_bytes(response_part[1])

                                # Additional hour precision check if "Last X Hours" is active
                                if filter_type == "Last X Hours":
                                    date_tuple = email.utils.parsedate_tz(
                                        msg.get("Date")
                                    )
                                    if date_tuple:
                                        local_date = datetime.fromtimestamp(
                                            email.utils.mktime_tz(date_tuple),
                                            tz=timezone.utc,
                                        )
                                        if local_date < time_threshold:
                                            continue  # Skip older than exact hours

                                subject = parse_header(msg.get("Subject"))
                                from_addr = parse_header(msg.get("From"))
                                date_str = msg.get("Date")

                                with st.expander(
                                    f"📌 **{subject}** — *From: {from_addr}*"
                                ):
                                    st.write(f"**Date:** {date_str}")

                                    # Extract email body
                                    body = ""
                                    if msg.is_multipart():
                                        for part in msg.walk():
                                            content_type = part.get_content_type()
                                            content_disposition = str(
                                                part.get("Content-Disposition")
                                            )

                                            if (
                                                content_type == "text/plain"
                                                and "attachment"
                                                not in content_disposition
                                            ):
                                                body = part.get_payload(
                                                    decode=True
                                                ).decode(errors="ignore")
                                                break
                                    else:
                                        body = msg.get_payload(decode=True).decode(
                                            errors="ignore"
                                        )

                                    st.text_area(
                                        "Body",
                                        body,
                                        height=150,
                                        key=f"body_{e_id.decode()}",
                                    )

                                fetched_count += 1

                mail.logout()

        except Exception as e:
            st.error(f"❌ Error fetching emails: {e}")
