from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
import os
import re
import smtplib
import sys
import time
import streamlit as st
import streamlit.components.v1 as components
from streamlit_quill import st_quill

# --- 0. BROWSER LOCAL STORAGE FOR 4-HOUR SESSION & REFRESH PERSISTENCE ---
LOGIN_TIMEOUT = 4 * 3600  # 4 Hours in Seconds

def init_local_storage_auth():
    js_code = """
    <script>
    const loginTime = localStorage.getItem('app_login_time');
    const authStatus = localStorage.getItem('app_authenticated');
    const currentTime = Math.floor(Date.now() / 1000);
    const timeout = 4 * 3600; // 4 Hours
    if (authStatus === 'true' && loginTime && (currentTime - parseInt(loginTime) < timeout)) {
        window.parent.postMessage({type: 'streamlit:setComponentValue', value: 'authenticated'}, '*');
    } else {
        localStorage.removeItem('app_authenticated');
        localStorage.removeItem('app_login_time');
        window.parent.postMessage({type: 'streamlit:setComponentValue', value: 'unauthenticated'}, '*');
    }
    </script>
    """
    return components.html(js_code, height=0, width=0)

# Initialize local storage check
if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

# --- 1. AUTHENTICATION LOGIC ---
if not st.session_state.get("authenticated", False):
    st.warning("🔒 Access Restricted!")
    user_pass = st.text_input("Please enter Password", type="password", key="auth_pass_input")
    CORRECT_PASSWORD = st.secrets.get("PASSWORD", "root")
    
    if st.button("Unlock Page"):
        if user_pass == CORRECT_PASSWORD:
            st.session_state["authenticated"] = True
            components.html("""
                <script>
                localStorage.setItem('app_authenticated', 'true');
                localStorage.setItem('app_login_time', Math.floor(Date.now() / 1000));
                </script>
            """, height=0)
            st.success("✅ Password correct!")
            st.rerun()
        else:
            st.error("❌ Incorrect password!")
            st.stop()
    else:
        st.stop()

# --- 2. SESSION STATE FOR SMTP CREDENTIALS ---
if "smtp_email" not in st.session_state:
    st.session_state["smtp_email"] = ""
if "smtp_user" not in st.session_state:
    st.session_state["smtp_user"] = ""
if "smtp_password" not in st.session_state:
    st.session_state["smtp_password"] = ""
if "smtp_server" not in st.session_state:
    st.session_state["smtp_server"] = "smtp.resend.com"
if "smtp_port" not in st.session_state:
    st.session_state["smtp_port"] = 587
if "smtp_name" not in st.session_state:
    st.session_state["smtp_name"] = "Mail Sender"

# --- HELPER FUNCTIONS ---
def parse_and_clean_emails(raw_input: str) -> list[str]:
    if not raw_input:
        return []
    tokens = re.split(r"[,\s;]+", raw_input)
    seen = set()
    cleaned = []
    for token in tokens:
        email = token.strip()
        if email and email not in seen:
            seen.add(email)
            cleaned.append(email)
    return cleaned

def is_valid_email(email: str) -> bool:
    pattern = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
    return re.match(pattern, email) is not None

# --- 3. SIDEBAR / FORM FOR SMTP LOGINS & LOGOUT ---
with st.sidebar:
    st.divider()
    st.title("⚙️ SMTP Login Config")
    
    s_email = st.text_input("Sender Email (From):", value=st.session_state["smtp_email"], placeholder="onboarding@resend.dev or your domain")
    s_user = st.text_input("SMTP Username:", value=st.session_state["smtp_user"], placeholder="resend")
    s_pass = st.text_input("SMTP Password / API Key:", value=st.session_state["smtp_password"], type="password", placeholder="re_12345...")
    s_server = st.text_input("SMTP Server / Host:", value=st.session_state["smtp_server"])
    s_port = st.number_input("SMTP Port:", value=int(st.session_state["smtp_port"]), step=1)
    s_name = st.text_input("Sender Name:", value=st.session_state["smtp_name"])

    if st.button("💾 Save SMTP Credentials", type="primary"):
        st.session_state["smtp_email"] = s_email.strip()
        st.session_state["smtp_user"] = s_user.strip()
        st.session_state["smtp_password"] = s_pass.strip()
        st.session_state["smtp_server"] = s_server.strip()
        st.session_state["smtp_port"] = s_port
        st.session_state["smtp_name"] = s_name.strip()
        st.success("✅ SMTP Login Saved!")
        st.rerun()

    if st.session_state["smtp_email"]:
        st.info(f"🔑 Logged in as: {st.session_state['smtp_user'] or st.session_state['smtp_email']}")
        
        if st.button("🔄 Reset Saved SMTP Credentials"):
            st.session_state["smtp_email"] = ""
            st.session_state["smtp_user"] = ""
            st.session_state["smtp_password"] = ""
            st.rerun()

    st.divider()
    
    # LOGOUT BUTTON (Clears LocalStorage & Session)
    if st.button("🚪 Logout App"):
        st.session_state["authenticated"] = False
        components.html("""
            <script>
            localStorage.removeItem('app_authenticated');
            localStorage.removeItem('app_login_time');
            </script>
        """, height=0)
        st.success("👋 Logged out successfully!")
        st.rerun()

# --- 4. MAIN EMAIL UI ---
st.title("📧 Dynamic SMTP Mail Sender")

if not st.session_state["smtp_email"] or not st.session_state["smtp_password"]:
    st.warning("⚠️ SMTP Credentials saved nahi hain! Sidebar me details daal kar 'Save SMTP Credentials' button dabaayein.")
else:
    st.success(f"🟢 Active SMTP Session: **{st.session_state['smtp_email']}**")

st.divider()

receiver_email_input = st.text_input("To (Receiver Email):")
bcc_email_input = st.text_input("BCC (Optional):")
subject = st.text_input("Subject:")

st.write("### Email Body (Rich Text Editor):")
message_html = st_quill(
    placeholder="Write your email here...",
    html=True,
    key="quill_editor_clean",
)

# --- 5. SEND EMAIL LOGIC ---
if st.button("🚀 Send Email", type="primary"):
    sender_email = st.session_state.get("smtp_email")
    smtp_username = st.session_state.get("smtp_user") or sender_email  # Fallback to sender_email if user left blank
    sender_password = st.session_state.get("smtp_password")
    smtp_server = st.session_state.get("smtp_server")
    smtp_port = st.session_state.get("smtp_port")
    sender_name = st.session_state.get("smtp_name")

    if not sender_email or not sender_password:
        st.error("❌ Pehle Sidebar me SMTP Credentials Save karein!")
        st.stop()

    to_recipients = parse_and_clean_emails(receiver_email_input)
    bcc_recipients = parse_and_clean_emails(bcc_email_input)
    all_recipients = to_recipients + bcc_recipients

    if not to_recipients or not subject.strip() or not message_html.strip():
        st.warning("⚠️ To, Subject aur Message required fields hain!")
        st.stop()

    invalid_emails = [e for e in all_recipients if not is_valid_email(e)]
    if invalid_emails:
        st.error(f"❌ Invalid email format: {', '.join(invalid_emails)}")
        st.stop()

    clean_formatted_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
    <style>
        p {{ margin: 0 0 4px 0 !important; padding: 0 !important; line-height: 1.3 !important; }}
        div {{ margin: 0 !important; line-height: 1.3 !important; }}
    </style>
    </head>
    <body style="font-family: Arial, sans-serif; font-size: 14px; color: #333333; line-height: 1.3;">
    {message_html}
    </body>
    </html>
    """

    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = formataddr((sender_name, sender_email))
        msg["To"] = ", ".join(to_recipients)
        msg["Subject"] = subject.strip()

        msg.attach(MIMEText("Please view in HTML format.", "plain"))
        msg.attach(MIMEText(clean_formatted_html, "html"))

        if int(smtp_port) == 465:
            with smtplib.SMTP_SSL(smtp_server, int(smtp_port)) as server:
                server.login(smtp_username, sender_password)
                server.sendmail(sender_email, all_recipients, msg.as_string())
        else:
            with smtplib.SMTP(smtp_server, int(smtp_port)) as server:
                server.starttls()
                server.login(smtp_username, sender_password)
                server.sendmail(sender_email, all_recipients, msg.as_string())

        st.success("✅ Email successfully sent!")
    except Exception as e:
        st.error(f"❌ Sending Failed: {e}")
